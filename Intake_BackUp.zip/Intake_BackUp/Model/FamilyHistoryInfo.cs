﻿namespace IntakeForm.Models
{
    public class FamilyHistoryInfo
    {
        public string Condition { get; set; }
        public string Relation { get; set; }
        public string SmokingStatus { get; set; }
    }
}
